from django.contrib import admin
from drf_advanced_token.models import UserAPIKeyLock

admin.site.register(UserAPIKeyLock)