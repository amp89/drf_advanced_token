from django.apps import AppConfig


class DrfAdvancedTokenConfig(AppConfig):
    name = 'drf_advanced_token'
